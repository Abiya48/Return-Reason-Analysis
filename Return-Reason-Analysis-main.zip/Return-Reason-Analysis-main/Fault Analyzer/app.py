from flask import Flask, request, render_template
from model import analyze_returns
import os
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Home page - upload CSV
@app.route("/", methods=["GET", "POST"])
def index():
    results = None
    if request.method == "POST":
        file = request.files['file']
        file_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(file_path)
        results = analyze_returns(file_path)
    return render_template("index.html", results=results)

# Predict from product link
@app.route("/predict", methods=["GET", "POST"])
def predict():
    prediction = None
    title = None
    if request.method == "POST":
        url = request.form.get("url")
        title = extract_amazon_title(url)
        prediction = predict_reason(title)
    return render_template("predict.html", title=title, prediction=prediction)

# Get product title from Amazon/Flipkart link
def extract_amazon_title(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    try:
        res = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(res.text, "html.parser")
        title = soup.find(id="productTitle") or soup.find("title")
        return title.get_text(strip=True) if title else "Unknown Product"
    except:
        return "Failed to extract product title"

# Dummy prediction logic
def predict_reason(product_title):
    title = product_title.lower()
    if any(x in title for x in ["shirt", "t-shirt", "jeans", "pant"]):
        return ["Wrong Size", "Color Not As Expected", "Fitting Issue"]
    elif any(x in title for x in ["mobile", "laptop", "watch", "headphone"]):
        return ["Defective Item", "Not Working", "Late Delivery"]
    else:
        return ["Damaged", "Received Different Product", "Poor Quality"]

if __name__ == "__main__":
    app.run(debug=True)
