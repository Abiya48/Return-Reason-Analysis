import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

def analyze_returns(file_path):
    df = pd.read_csv(file_path)
    df['Return Reason'] = df['Return Reason'].fillna("")

    vectorizer = TfidfVectorizer(stop_words='english')
    X = vectorizer.fit_transform(df['Return Reason'])

    kmeans = KMeans(n_clusters=3, random_state=42).fit(X)
    df['Reason Group'] = kmeans.labels_

    top_reasons = df['Return Reason'].value_counts().head(5).to_dict()
    category_returns = df['Category'].value_counts().to_dict()

    return {
        'top_reasons': top_reasons,
        'category_returns': category_returns
    }
